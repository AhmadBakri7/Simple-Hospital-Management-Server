package com.example.demo.controller;


import com.example.demo.models.Patient;
import com.example.demo.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
@RestController
public class PatientController {

    @Autowired
    PatientService PatientService;
    @RequestMapping("/patients")
    public ArrayList<Patient> getAllPatients() {
        return PatientService.getPatientList();
    }

    @RequestMapping(method=RequestMethod.GET,value="/patients/{id}")
    public Object GetPatientsId(@PathVariable Long id) {
        return PatientService.getPatientListId(id);
    }

    @RequestMapping(method= RequestMethod.POST, value="/patients")
    public boolean addPatient(@RequestBody Patient patient) {
        return PatientService.addPatient(patient);
    }

    @RequestMapping(method=RequestMethod.DELETE,value="/patients/{id}")
    public boolean deletePatient(@PathVariable Long id) {
        return PatientService.deletePatient(id);
    }

    @PutMapping("/release/{patientId}")
    public boolean releasePatient(@PathVariable Long patientId) {
        PatientService.releasePatient(patientId);
        return true;
    }

//    @PutMapping("/release/{patientId}")
//    public boolean releasePatient(@PathVariable Long patientId) {
//        return PatientService.releasePatient(patientId);
//    }
}
