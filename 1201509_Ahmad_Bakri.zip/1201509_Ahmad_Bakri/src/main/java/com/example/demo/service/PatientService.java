package com.example.demo.service;



import com.example.demo.models.Patient;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

@Service
public class PatientService {

    private static ArrayList<Patient> patientList = new
            ArrayList<Patient>(Arrays.asList(
            new Patient(1L, "Patient Motaz", 5.3, false, new ArrayList<Long>(Arrays.asList(1L, 2L))),
            new Patient(2L, "Patient Mohamad", 3.2, false, new ArrayList<Long>(Arrays.asList(1L))),
            new Patient(3L, "Patient Diaa", 4.4, false, new ArrayList<Long>(Arrays.asList()))

            ));

    public ArrayList<Patient> getPatientList() {
        return this.patientList;
    }

    public Object getPatientListId(Long id) {

        for (Patient patient : patientList) {
            if (patient.getId().equals(id)) {
                return patient;
            }
        }
        return "Patient not found with id: " + id;
    }


    public boolean addPatient(Patient patient) {
        return patientList.add(patient);
    }

    public boolean deletePatient(Long id) {
        Patient patient = (Patient) getPatientListId(id);
        if (patient != null) {
            return patientList.remove(patient);
        }
        return false;
    }

    public static Optional<Patient> FindPatient(long id){

        for (Patient patient : patientList){
            if (patient.getId() == id)
                return Optional.of(patient);
        }

        return Optional.empty();
    }

    public void releasePatient(Long pId) {
        Optional<Patient> AsPatient = FindPatient(pId);

        if (AsPatient.isPresent()) {
            Patient patient = AsPatient.get();
            patient.setCured(true);
            patient.getDoctors().clear();
        }
    }





}
