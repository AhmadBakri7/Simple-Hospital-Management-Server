package com.example.demo.controller;

import com.example.demo.models.Patient;
import com.example.demo.models.Doctor;
import com.example.demo.service.DoctorService;
import com.example.demo.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
public class DoctorController {

    @Autowired
    DoctorService DoctorService;
    @Autowired
    PatientService PatientService;

    @RequestMapping("/doctors")
    public ArrayList<Doctor> getAllDoctors() {
        return DoctorService.getDoctorList();
    }

    @RequestMapping(method=RequestMethod.GET,value="/doctors/{id}")
    public Object GetDoctorId(@PathVariable Long id) {
        return DoctorService.getDoctorListId(id);
    }


    @RequestMapping(method= RequestMethod.POST, value="/doctors")
    public boolean addDoctor(@RequestBody Doctor doctor) {
        return DoctorService.addDoctor(doctor);
    }

    @RequestMapping(method=RequestMethod.DELETE,value="/doctors/{id}")
    public boolean deleteDoctor(@PathVariable Long id) {
        return DoctorService.deleteDoctor(id);
    }

    @PostMapping("/assign/{doctorId}")
    public boolean assignDoctor(@PathVariable long doctorId, @RequestBody long patientId) {
        return DoctorService.assignDoctor(doctorId, PatientService.FindPatient(patientId).get());
    }
    @RequestMapping(method=RequestMethod.GET,value="/")
    public String welcome() {
        return DoctorService.welcome();
    }

}
