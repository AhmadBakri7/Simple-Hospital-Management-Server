package com.example.demo.service;

import com.example.demo.models.Doctor;
import com.example.demo.models.Patient;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;

@Service
public class DoctorService {
    private ArrayList<Doctor> doctorList = new
            ArrayList<Doctor>(Arrays.asList(
            new Doctor(1L, "Doctor Ahmad", 5, 3, 2.2),
            new Doctor(2L, "Doctor samah", 4, 2, 16.5),
            new Doctor(3L, "Doctor Rateb", 3, 1, 30.2)
    ));

    public ArrayList<Doctor> getDoctorList() {
        return this.doctorList;
    }

    public String welcome() {
        return "Welcome, I’m Ahmad_Bakri";
    }

    public Object getDoctorListId(Long id) {

        for (Doctor doctor : doctorList) {
            if (doctor.getId().equals(id)) {
                return doctor;
            }
        }
        return "Doctor not found with id: " + id;
    }


    public boolean addDoctor(Doctor doctor) {
        return doctorList.add(doctor);
    }

    public boolean deleteDoctor(Long id) {
        Doctor doctor = (Doctor) getDoctorListId(id);
        if (doctor != null) {
            return doctorList.remove(doctor);
        }
        return false;
    }

    public Optional<Doctor> FindDoctor(long id){

        for (Doctor doctor : doctorList){
            if (doctor.getId() == id)
                return Optional.of(doctor);
        }

            return Optional.empty();
    }

    public boolean assignDoctor(Long docId, Patient patient) {
        Optional<Doctor> AsDoctor = FindDoctor(docId);

        if (AsDoctor.isPresent()) {
            Doctor doctor = AsDoctor.get();
            if (doctor.getExperience() >= patient.getIllnessExperienceRequirement() && doctor.getCurrentPatients() < doctor.getMaxPatients()) {
                doctor.setCurrentPatients(doctor.getCurrentPatients() + 1);
                patient.getDoctors().add(docId);
                return true;
            }
        }
        return false;
    }
}
